
public class FASE2 {

	public static void main(String[] args) {
		final int any=1948;
		int periodo_bisiesto=4;
		int naixement=1993;
		int a=(naixement-any)/periodo_bisiesto;
		System.out.println("Entre el a�o de mi nacimiento y 1948 hay " + a + " a�os bisiestos, sin contar el a�o 1948");
	}

}
