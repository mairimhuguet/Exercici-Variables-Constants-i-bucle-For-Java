
public class FASE4 {

	public static void main(String[] args) {
		String nomcomplet="Miriam Huguet Aguilera";
		
			String naixement = "11/01/1993";
			
			String traspas = "El meu any de naixement no �s de trasp�s";
		
			System.out.println("El meu nom �s " + nomcomplet);
			System.out.println("Vaig n�ixer el " + naixement);
			System.out.println(traspas);
	}

}
