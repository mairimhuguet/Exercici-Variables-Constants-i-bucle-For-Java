
public class FASE1 {

	public static void main(String[] args) {
		String nom="Miriam";
		String cognom1="Huguet";
		String cognom2="Aguilera";

		System.out.println("Mi nombre es " + cognom1 + " " + cognom2 + ", " + nom);
		
		
			int dia=22;
			int mes=7;
			int any=2020;

			System.out.println("Ejercicio realizado el " + dia + "/" + mes + "/" + any);
		
	}

}
